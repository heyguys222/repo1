/* Update the main below to:
     Create one Box object with length 5 and width 5
     Create another Box object with length 8 and width 10
     Print all about both objects
     Update the first Box so that it's width is 20
     Print out the area of the first Box object
     Update the second Box so that it's length is 5
     Print out all about the second Box
     Print out ONLY the width of both Box objects
     Print out ONLY the length of both Box objects
*/


public class BoxApp {

    public static void main (String[] args) {
        Box Box1 = new Box(); //Create new box objects
        Box Box2 = new Box(); //initialize length and width to 5

        Box2.setLength(8); //Set length and width of box2 to 8 and 10
        Box2.setWidth(10);
        Box1.printAll(); //Print all information about both boxes
        Box2.printAll();

        Box1.setWidth(20); //Set the width of box1 to 20
        Box1.printArea(); //Print the area of box1

        Box2.setLength(5); //Set length of box2 to 5
        Box2.printAll();

        Box1.getWidth();
        Box2.getWidth();
        System.out.println("Width of box 1: " + Box1.getWidth() );
        System.out.println("Width of box 2: " + Box2.getWidth() );
        System.out.println("Length of box 1: " + Box1.getLength() );
        System.out.println("Length of box 2: " + Box2.getLength() );









    }

}